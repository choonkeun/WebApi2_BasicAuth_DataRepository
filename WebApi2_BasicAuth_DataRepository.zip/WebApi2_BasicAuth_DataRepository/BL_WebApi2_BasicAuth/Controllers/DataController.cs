﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data.SqlClient;

using System.Data;
using System.Collections.Specialized;   //NameValueCollection
using System.Web;                       //HttpUtility
using System.Net.Http;                  //HttpResponseMessage
using System.Net;                       //HttpStatusCode
using System.Security.Claims;

using BL_WebApi2_BasicAuth.Filters;
using BL_WebApi2_BasicAuth.Data.Models;
using BL_WebApi2_BasicAuth.Data.Interfaces;

// https://www.youtube.com/watch?v=_SfK-2MEbcE

namespace BL_WebApi2_BasicAuth.Controllers
{
    //[BasicAuthorizationFilter(false)] //Do not process "[BasicAuthorizationFilter]"
    [BasicAuthorizationFilter]          //step 1: check Authorization: Basic RnVsbGVyOkFuZHJldw==
    [BasicAuthorizationAttribute]       //step 2: check username,password
    [ValidationFilterAttribute]         //step 3: check ModelBinding if needed such as PUT,POST - Controller Level

    [RoutePrefix("Data")]
    public class DataController : ApiController
    {

        private IEmployeeRepository _data = new EmployeeRepository();

        // GET http://localhost:1605/swagger/ Type Username, password (Buchanan, Steven)
        // GET http://localhost:1605/data/GetAll
        // Authorization: Basic QWxhZGRpbjpPcGVuU2VzYW1l

        [AllowAnonymous]
        [HttpGet]
        [Route("GetAll")]
        public List<Employee> GetAll()
        {
            //var identity = (ClaimsIdentity)User.Identity;

            List<Employee> employees = _data.GetAllEmployees();
            return employees;
        }


        [HttpGet]
        [Route("Get")]
        [Authorize]         //any user who is Authorized with Role
        public IEnumerable<string> Get()
        {
            //GET http://localhost:1605/data/GetAll?var1=1&var2=2+2%2f3&var1=3
            NameValueCollection nvc = HttpUtility.ParseQueryString(Request.RequestUri.Query);
            var var1 = nvc["var1"];

            return new string[] { "value1", "value2", var1 };
            //return Ok("Now server time is: " + DateTime.Now.ToString());
        }

        // GET
        // http://localhost:1605/data/GetEmployeeById/1
        // Authorization: Basic QnVjaGFuYW46U3RldmVu (Buchanan:Steven) 1
        // Authorization: Basic Q2FsbGFoYW46TGF1cmE = (Callahan:Laura) 3
        // Authorization: Basic U3V5YW1hOk1pY2hhZWw = (Suyama:Michael) 5

        [OverrideActionFiltersAttribute]    //Disable [ValidationFilterAttribute]
        [HttpGet]
        [Route("GetEmployeeById/{id}")]
        public Employee Get(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;
            // http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name      value:Buchanan
            // http://schemas.microsoft.com/ws/2008/06/identity/claims/role    value:admin
            // username                                                        value:Buchanan
            // title                                                           value: Sales Manager
            // http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name      value:Buchanan

            Employee employee = _data.GetEmployeeById(id);
            return employee;  
        }


        // http://localhost:1605/data/Post
        // Header: Content-Type: application/x-www-form-urlencoded
        // Body: =foo_bar
        //[HttpPost]
        //[ActionName("Post")]
        //public string Post([FromBody]string value)
        //{
        //    return "Insert " + value;
        //}

        // https://weblog.west-wind.com/posts/2012/May/08/Passing-multiple-POST-parameters-to-Web-API-Controller-Methods
        // -------------------------------------------------------------------------------------
        // Web API expects you to use Model Binding
        // 1. Mapping the post parameters to a "strongly typed .NET object", not to single parameters
        // 2. FormDataCollection parameter to get a name value collection of all POSTed values
        // -------------------------------------------------------------------------------------


        // http://localhost:1605/data/Employee --> INSERT
        // Authorization: Basic QnVjaGFuYW46U3RldmVu
        // Content-Type: application/json
        // accept: application/json

        [HttpPost]
        [Route("Employee")]
        public HttpResponseMessage Post(Employee employee)
        {
            var identity = (ClaimsIdentity)User.Identity;

            HttpResponseMessage resp = _data.PostEmployee(employee);
            return resp;
        }


        // PUT 
        // http://localhost:1605/data/Employee --> UPDATE
        // Header: Content-Type: application/json
        [ValidationFilterAttribute]     //check ModelBinding - Action Level
        [Route("Employee")]
        [HttpPut]
        [Authorize(Roles = "admin")]
        //[Authorize(Roles = "user")]
        public string Put(Employee employee)
        {
            if (employee.EmployeeID.ToString().Length < 1 || employee.EmployeeID == 0)
            {
                throw new HttpResponseException(Request.CreateErrorResponse(
                    HttpStatusCode.NotFound, String.Format("EmployeeID not found fro {0}.", employee.EmployeeID)
                ));
            }

            var identity = (ClaimsIdentity)User.Identity;

            string resp = _data.PutEmployee(employee);
            return resp;
        }


        // DELETE
        // http://localhost:1605/data/DeleteEmployeeById/3 --> DELETE
        [OverrideActionFiltersAttribute]    //Disable [ValidationFilterAttribute]
        [HttpDelete]
        [Route("DeleteEmployeeById/{id}")]
        [Authorize(Roles = "admin")]
        public string Delete(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;

            string resp = _data.DeleteEmployeeById(id);
            return resp;
        }

    }
}
