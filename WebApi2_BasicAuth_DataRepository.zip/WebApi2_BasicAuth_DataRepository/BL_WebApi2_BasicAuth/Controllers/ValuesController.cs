﻿using System.Collections.Generic;
using System.Web.Http;
using BL_WebApi2_BasicAuth.Filters;

namespace BL_WebApi2_BasicAuth.Controllers
{
    [BasicAuthorizationFilter]
    [RoutePrefix("Values")]
    public class ValuesController : ApiController
    {
        //
        //GET http://localhost:1605/Values/GetAll
        [HttpGet]
        [Route("GetAll")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
