﻿using System;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Text;
using System.Net.Http;
using System.Net;
using System.Security.Claims;
using System.Collections.Generic;
using BL_WebApi2_BasicAuth.Data.Models;
using BL_WebApi2_BasicAuth.Data.Interfaces;

namespace BL_WebApi2_BasicAuth.Filters
{
    public class BasicAuthorizationAttribute : AuthorizeAttribute
    {
        private IEmployeeRepository _data = new EmployeeRepository();

        //static string conStr = string.Empty;
        //static BasicAuthorizationAttribute() 
        //{
        //    string baseDir = AppDomain.CurrentDomain.BaseDirectory;
        //    AppDomain.CurrentDomain.SetData("DataDirectory", baseDir);
        //    conStr = System.Configuration.ConfigurationManager.ConnectionStrings["ConnString3"].ConnectionString;
        //}

        public override void OnAuthorization(HttpActionContext actionContext)
        {

            if (actionContext.Request.Headers.Authorization != null)
            {
                var authConcat = Encoding.UTF8.GetString(Convert.FromBase64String(actionContext.Request.Headers.Authorization.Parameter));
                var username = authConcat.Split(':')[0];
                var password = authConcat.Split(':')[1];

                //if (username == "username" && password == "password")
                //{
                //    actionContext.ControllerContext.RequestContext.Principal = new GenericPrincipal(new GenericIdentity(username), new string[] { });
                //    return;     // and continue with controller
                //}

                Employee employee = _data.GetEmployeeByUserName(username, password);

                //user not found
                if (employee.EmployeeID == 0)
                {
                    actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                    return;
                }

                var claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.Name, username));

                if (employee.ReportsTo <= 2)  //myRole(1 or 2)
                {
                    claims.Add(new Claim(ClaimTypes.Role, "admin"));
                    claims.Add(new Claim("username", username));
                    claims.Add(new Claim("title", employee.Title));
                    claims.Add(new Claim(ClaimTypes.Name, username));
                    var identity = new ClaimsIdentity(claims, "Basic");
                    var principal = new ClaimsPrincipal(identity);
                    actionContext.ControllerContext.RequestContext.Principal = principal;
                    return;     // and continue with controller
                }
                else if (employee.ReportsTo <= 4)  //user(3 or 4), part time(5)
                {
                    claims.Add(new Claim(ClaimTypes.Role, "user"));
                    claims.Add(new Claim(ClaimTypes.Name, username));
                    claims.Add(new Claim("username", username));
                    claims.Add(new Claim("title", employee.Title));
                    var identity = new ClaimsIdentity(claims, "Basic");
                    var principal = new ClaimsPrincipal(identity);
                    actionContext.ControllerContext.RequestContext.Principal = principal;
                    return;     // and continue with controller
                }
            }
            //Authentication failed - user not found or password not match
            actionContext.Response = new HttpResponseMessage(HttpStatusCode.NotFound)
            {
                Content = new StringContent("Provided username and password is incorrect")
            };
        }
    }



}