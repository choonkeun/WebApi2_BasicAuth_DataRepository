﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Http;

namespace BL_WebApi2_BasicAuth.Filters
{
    //
    // Authentication and Authorization
    //

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class BasicAuthorizationFilter : AuthorizationFilterAttribute
    {
        bool Active = true;

        //ConnStringuctor
        public BasicAuthorizationFilter() { }
        public BasicAuthorizationFilter(bool active) { Active = active; }


        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if (Active)
            {
                //parse Authorization in Header
                var identity = ParseAuthorizationHeader(actionContext);
                if (identity == null)
                {
                    Challenge(actionContext);
                    return;
                }

                //Authorize User with username and password
                if (!OnAuthorizeUser(identity.Name, identity.Password, actionContext))
                {
                    Challenge(actionContext);
                    return;
                }

                var principal = new GenericPrincipal(identity, null);

                Thread.CurrentPrincipal = principal;

                base.OnAuthorization(actionContext);
            }
        }


        //parse Authorization in Header
        protected virtual BasicAuthenticationIdentity ParseAuthorizationHeader(HttpActionContext actionContext)
        {
            string authHeader = null;
            var auth = actionContext.Request.Headers.Authorization;
            if (auth != null && auth.Scheme == "Basic")
                authHeader = auth.Parameter;

            if (string.IsNullOrEmpty(authHeader))
                return null;
            try
            {
                authHeader = Encoding.Default.GetString(Convert.FromBase64String(authHeader));
                // find first : as password allows for :
                int idx = authHeader.IndexOf(':');
                if (idx < 0)
                    return null;

                string username = authHeader.Substring(0, idx);
                string password = authHeader.Substring(idx + 1);

                return new BasicAuthenticationIdentity(username, password);
            }
            catch (Exception)
            {
                string ErrorMessage = "Authorization failed";
                throw new HttpResponseException(actionContext.Request.CreateErrorResponse(
                                                    HttpStatusCode.Unauthorized, ErrorMessage));
            }

        }

        //parse Authorization in Header
        public class BasicAuthenticationIdentity : GenericIdentity
        {
            public BasicAuthenticationIdentity(string name, string password) : base(name, "Basic")
            {
                this.Password = password;
            }
            public string Password { get; set; }
        }


        //Authorize User with username and password
        protected virtual bool OnAuthorizeUser(string username, string password, HttpActionContext actionContext)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return false;

            return true;
        }

        //return "Unauthorized"
        void Challenge(HttpActionContext actionContext)
        {
            var host = actionContext.Request.RequestUri.DnsSafeHost;
            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            //actionContext.Response.Headers.Add("WWW-Authenticate", string.Format("Basic realm=\"{0}\"", host));
            actionContext.Response.Headers.Add("WWW-Authenticate", "Invalid");
        }
    }


}