﻿using System;
using System.Net;
using System.Threading;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using ActionFilterAttribute = System.Web.Http.Filters.ActionFilterAttribute;
using System.Collections.Generic;
using System.Diagnostics;
using BL_WebApi2_BasicAuth.Data.Models;

namespace BL_WebApi2_BasicAuth.Filters
{

    public class ValidationFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            // To get posted formdata as model binding, check the model is correct or not
            // So, use "reflection" to inspect class using metadata
            // get instance: obj.GetType().GetProperties();
            // get type    : typeof(Foo).GetProperties();
            //--
            //class Foo {
            //    public int    A {get;set;}
            //    public string B {get;set;}
            //}
            //Foo foo = new Foo {A = 1, B = "abc"};
            //foreach(var prop in foo.GetType().GetProperties()) {
            //    Console.WriteLine("{0}={1}", prop.Name, prop.GetValue(foo, null));
            //}

            if (!actionContext.ModelState.IsValid)
            {
                //actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, actionContext.ModelState);
                string ErrorMessage = "request data has invalid format";
                throw new HttpResponseException(
                    actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, ErrorMessage));

            }

            var arg = actionContext.ActionArguments;
            foreach (var state in arg)
            {
                List<string> model = GetPropertiesNameOfClass(state);

                Employee emp = (Employee)state.Value;
                List<string> meta = GetPropertiesNameOfClass(emp);

                foreach (var prop in emp.GetType().GetProperties())
                {
                    var propValue = prop.GetValue(emp, null);    //To get the value of static properties
                    if (propValue != null)
                    {
                        Console.WriteLine(prop.GetValue(emp, null));
                        Debug.WriteLine(prop.GetValue(emp, null));
                    }
                    else
                    {
                        string ErrorMessage = "request data has invalid format";
                        throw new HttpResponseException(
                            actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, ErrorMessage));
                    }
                }
            }

        }

        //System.Reflection: To inspect class 
        public List<string> GetPropertiesNameOfClass(object obj)
        {
            List<string> propertyList = new List<string>();
            if (obj != null)
            {
                foreach (var prop in obj.GetType().GetProperties())
                {
                    string classItems = string.Format("{0}={1}", prop.Name, prop.GetValue(obj, null));
                    propertyList.Add(classItems);
                    //propertyList.Add(prop.Name);
                    Debug.WriteLine("{0}={1}", prop.Name, prop.GetValue(obj, null));
                }
            }
            return propertyList;
        }
    }

    //Always return Error
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class FailRequestAttribute : ActionFilterAttribute
    {
        public HttpStatusCode StatusCode = HttpStatusCode.InternalServerError;
        public string ErrorMessage;
        public int Delay = 0;
        private const string DefaultErrorMessage = "** This is caused by the FailRequest ActionFilter **";

        public override void OnActionExecuting(HttpActionContext filterContext)
        {
            if (ErrorMessage == null)
            {
                ErrorMessage = string.Format("{0}. This error was fired on the {1} Action of the {2} Controller.",
                                             DefaultErrorMessage, filterContext.ActionDescriptor.ActionName,
                                             filterContext.ActionDescriptor.ControllerDescriptor.ControllerName);
            }
            Thread.Sleep(Delay);
            throw new HttpResponseException(filterContext.Request.CreateErrorResponse(StatusCode, ErrorMessage));
        }
    }

}